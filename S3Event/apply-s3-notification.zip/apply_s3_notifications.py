#  Copyright 2016 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
#  This file is licensed to you under the AWS Customer Agreement (the "License").
#  You may not use this file except in compliance with the License.
#  A copy of the License is located at http://aws.amazon.com/agreement/ .
#  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, express or implied.
#  See the License for the specific language governing permissions and limitations under the License.
import requests
import json
import logging
import boto3
from itertools import starmap

SUCCESS = "SUCCESS"
FAILED = "FAILED"
S3 = boto3.client('s3')

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


# Copied from https://github.com/awslabs/aws-cloudformation-templates/blob/master/aws/services/CloudFormation/MacrosExamples/StackMetrics/lambda/cfnresponse.py
def cfnresponse_send(event,
                     context,
                     responseStatus,
                     responseData,
                     physicalResourceId=None,
                     noEcho=False):
    responseUrl = event['ResponseURL']

    logging.debug(responseUrl)
    # print(responseUrl)

    responseBody = {}
    responseBody['Status'] = responseStatus
    responseBody[
        'Reason'] = 'See the details in CloudWatch Log Stream: ' + context.log_stream_name
    responseBody[
        'PhysicalResourceId'] = physicalResourceId or context.log_stream_name
    responseBody['StackId'] = event['StackId']
    responseBody['RequestId'] = event['RequestId']
    responseBody['LogicalResourceId'] = event['LogicalResourceId']
    responseBody['NoEcho'] = noEcho
    responseBody['Data'] = responseData
    json_responseBody = json.dumps(responseBody)
    logging.debug("Response:\n" + json_responseBody)
    headers = {
        'content-type': '',
        'content-length': str(len(json_responseBody))
    }
    try:
        response = requests.put(responseUrl,
                                data=json_responseBody,
                                headers=headers)
        print("Status code: " + response.reason)
    except Exception as e:
        print("send(..) failed executing requests.put(..): " + str(e))


def add_bucket_notification(bucket_name, notification_ids, functions_arn,
                            suffixes):
    def lambda_function_configuration(notification_id, function_arn, suffix):
        return {
            'Id': notification_id,
            'LambdaFunctionArn': function_arn,
            'Events': ['s3:ObjectCreated:*'],
            "Filter": {
                "Key": {
                    "FilterRules": [{
                        "Name": "suffix",
                        "Value": suffix
                    }]
                }
            }
        }

    lambda_function_configurations = list(
        starmap(lambda_function_configuration,
                zip(notification_ids, functions_arn, suffixes)))
    logger.debug(
        "Lambda configurations: {}".format(lambda_function_configurations))
    notification_response = S3.put_bucket_notification_configuration(
        Bucket=bucket_name,
        NotificationConfiguration={
            'LambdaFunctionConfigurations': lambda_function_configurations
        })
    return notification_response


def create(properties, physical_id):
    bucket_name = properties['S3Bucket']
    suffixes = properties['Suffixes']
    notification_ids = properties['NotificationIds']
    functions_arn = properties['FunctionsARN']
    logger.debug("Create physical id {} with properties: {}".format(
        physical_id, properties))
    response = add_bucket_notification(bucket_name, notification_ids,
                                       functions_arn, suffixes)
    logger.info('AddBucketNotification response: %s' % json.dumps(response))
    return SUCCESS, physical_id


def update(properties, physical_id):
    return SUCCESS, None


def delete(properties, physical_id):
    return SUCCESS, None


def handler(event, context):
    logger.info('Received event: %s' % json.dumps(event))

    status = FAILED
    new_physical_id = None

    try:
        properties = event.get('ResourceProperties')
        physical_id = event.get('PhysicalResourceId')

        event_type = event['RequestType']

        def lambda_failed(x, y):
            return FAILED, None

        actions = {'Create': create, 'Update': update, 'Delete': delete}

        process = actions.get(event_type, lambda_failed)
        status, new_physical_id = process(properties, physical_id)
        logger.info("Status: {}, new physical ID: {}".format(
            status, new_physical_id))
    except Exception as e:
        logger.error('Exception: %s' % e)
        status = FAILED
    finally:
        cfnresponse_send(event, context, status, {}, new_physical_id)